
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'travishoover',
  applicationName: 'pr-peddler',
  appUid: 'lZ96WptG2kVxyNgFPd',
  orgUid: 'hSwxXKzG7q7wtJzZDZ',
  deploymentUid: '5ff00e71-5e66-4261-a4a8-314d7dfaf4fe',
  serviceName: 'pr-peddler',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pr-peddler-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}